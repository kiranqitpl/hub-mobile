import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-telehandler',
  templateUrl: './telehandler.page.html',
  styleUrls: ['./telehandler.page.scss'],
})
export class TelehandlerPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
