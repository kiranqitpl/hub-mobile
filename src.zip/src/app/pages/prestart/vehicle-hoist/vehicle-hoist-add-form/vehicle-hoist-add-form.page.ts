import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-hoist-add-form',
  templateUrl: './vehicle-hoist-add-form.page.html',
  styleUrls: ['./vehicle-hoist-add-form.page.scss'],
})
export class VehicleHoistAddFormPage implements OnInit {

  pName: String = 'Vehicle Hoist'

  constructor() { }

  ngOnInit() {
  }

}
